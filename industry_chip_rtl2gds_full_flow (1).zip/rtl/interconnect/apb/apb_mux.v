`timescale 1ns/1ps
module apb_mux #(parameter N=8, AW=32, DW=32)(
    input wire pclk, input wire presetn,
    input wire psel_in, input wire pena_in, input wire pwrite_in,
    input wire [AW-1:0] paddr_in, input wire [DW-1:0] pwdata_in,
    output reg [DW-1:0] prdata_out, output reg pready_out, output reg pslverr_out,
    output reg  [N-1:0] psel_out,
    input  wire [N*DW-1:0] prdata_in, input wire [N-1:0] pready_in, input wire [N-1:0] pslverr_in
);
    wire [$clog2(N)-1:0] sel = paddr_in[AW-1:AW-$clog2(N)];
    always @(*) begin
        psel_out={N{1'b0}}; psel_out[sel]=psel_in;
        prdata_out=prdata_in[sel*DW+:DW]; pready_out=pready_in[sel]; pslverr_out=pslverr_in[sel];
    end
endmodule
