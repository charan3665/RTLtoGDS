// apb_bridge.v - AXI4-Lite to APB3 Bridge
`timescale 1ns/1ps
module apb_bridge #(parameter AW=32, DW=32)(
    input wire aclk, input wire aresetn,
    // AXI4-Lite slave
    input  wire        s_awvalid, input wire [AW-1:0] s_awaddr, output wire s_awready,
    input  wire        s_wvalid,  input wire [DW-1:0] s_wdata, input wire [DW/8-1:0] s_wstrb, output wire s_wready,
    output reg         s_bvalid,  output reg [1:0] s_bresp, input wire s_bready,
    input  wire        s_arvalid, input wire [AW-1:0] s_araddr, output wire s_arready,
    output reg         s_rvalid,  output reg [DW-1:0] s_rdata, output reg [1:0] s_rresp, input wire s_rready,
    // APB master
    output reg         psel, output reg pena, output reg pwrite,
    output reg [AW-1:0] paddr, output reg [DW-1:0] pwdata,
    input  wire [DW-1:0] prdata, input wire pready, input wire pslverr
);
    localparam ST_IDLE=3'd0,ST_AW=3'd1,ST_AR=3'd2,ST_SETUP=3'd3,ST_ENABLE=3'd4,ST_RESP=3'd5;
    reg [2:0] state;
    reg is_wr;
    assign s_awready=(state==ST_IDLE||state==ST_AW);
    assign s_wready =(state==ST_AW);
    assign s_arready=(state==ST_IDLE);
    always @(posedge aclk or negedge aresetn) begin
        if(!aresetn) begin state<=ST_IDLE; psel<=0; pena<=0; s_bvalid<=0; s_rvalid<=0; end
        else begin
            case(state)
                ST_IDLE: begin
                    s_bvalid<=0; s_rvalid<=0;
                    if(s_awvalid) begin paddr<=s_awaddr; is_wr<=1; state<=ST_AW; end
                    else if(s_arvalid) begin paddr<=s_araddr; is_wr<=0; psel<=1; pwrite<=0; pena<=0; state<=ST_SETUP; end
                end
                ST_AW: if(s_wvalid) begin pwdata<=s_wdata; pwrite<=1; psel<=1; pena<=0; state<=ST_SETUP; end
                ST_SETUP: begin pena<=1; state<=ST_ENABLE; end
                ST_ENABLE: if(pready) begin
                    psel<=0; pena<=0;
                    if(is_wr) begin s_bvalid<=1; s_bresp<=pslverr?2'b10:2'b00; state<=ST_RESP; end
                    else begin s_rvalid<=1; s_rdata<=prdata; s_rresp<=pslverr?2'b10:2'b00; state<=ST_RESP; end
                end
                ST_RESP: begin
                    if(is_wr&&s_bready) begin s_bvalid<=0; state<=ST_IDLE; end
                    if(!is_wr&&s_rready) begin s_rvalid<=0; state<=ST_IDLE; end
                end
            endcase
        end
    end
endmodule
