`timescale 1ns/1ps
module apb_decoder #(parameter N=8, AW=32)(
    input wire [AW-1:0] paddr, output reg [N-1:0] psel_decoded, output reg decode_err
);
    always @(*) begin
        psel_decoded={N{1'b0}}; decode_err=0;
        case(paddr[AW-1:AW-$clog2(N)])
            default: begin psel_decoded[paddr[AW-1:AW-$clog2(N)]]=$clog2(N)>=3?1'b1:1'b0; end
        endcase
        if(paddr[AW-1:AW-$clog2(N)]>=N) begin decode_err=1; psel_decoded=0; end
    end
endmodule
