// ahb2axi_bridge.v - AHB5 to AXI4 Bridge
`timescale 1ns/1ps
module ahb2axi_bridge #(parameter AW=32, DW=64, IW=4)(
    input wire HCLK, input wire HRESETn,
    // AHB slave
    input  wire [AW-1:0] HADDR, input wire [2:0] HBURST, input wire [2:0] HSIZE,
    input  wire [1:0] HTRANS, input wire [DW-1:0] HWDATA, input wire HWRITE,
    input  wire HSEL, input wire HREADY_IN,
    output reg [DW-1:0] HRDATA, output reg HREADY_OUT, output reg HRESP,
    // AXI4 master
    output reg m_awvalid, output reg [AW-1:0] m_awaddr, output reg [IW-1:0] m_awid,
    output reg [7:0] m_awlen, output reg [2:0] m_awsize, output reg [1:0] m_awburst,
    input  wire m_awready,
    output reg m_wvalid, output reg [DW-1:0] m_wdata, output reg [DW/8-1:0] m_wstrb, output reg m_wlast,
    input  wire m_wready,
    input  wire m_bvalid, input wire [IW-1:0] m_bid, input wire [1:0] m_bresp, output wire m_bready,
    output reg m_arvalid, output reg [AW-1:0] m_araddr, output reg [IW-1:0] m_arid,
    output reg [7:0] m_arlen, output reg [2:0] m_arsize, output reg [1:0] m_arburst,
    input  wire m_arready,
    input  wire m_rvalid, input wire [IW-1:0] m_rid, input wire [DW-1:0] m_rdata,
    input  wire [1:0] m_rresp, input wire m_rlast, output wire m_rready
);
    localparam ST_IDLE=3'd0, ST_AW=3'd1, ST_WD=3'd2, ST_AR=3'd3, ST_RD=3'd4;
    reg [2:0] state;
    assign m_bready=1; assign m_rready=1;
    always @(posedge HCLK or negedge HRESETn) begin
        if(!HRESETn) begin state<=ST_IDLE; m_awvalid<=0; m_wvalid<=0; m_arvalid<=0; HREADY_OUT<=1; end
        else begin
            m_awvalid<=0; m_wvalid<=0; m_arvalid<=0;
            case(state)
                ST_IDLE: if(HSEL&&HREADY_IN&&HTRANS>=2'b10) begin
                    if(HWRITE) begin m_awvalid<=1; m_awaddr<=HADDR; m_awlen<=0; m_awsize<=HSIZE; m_awburst<=2'b01; m_awid<=0; state<=ST_AW; HREADY_OUT<=0; end
                    else       begin m_arvalid<=1; m_araddr<=HADDR; m_arlen<=0; m_arsize<=HSIZE; m_arburst<=2'b01; m_arid<=0; state<=ST_AR; HREADY_OUT<=0; end
                end
                ST_AW: if(m_awready) begin m_wvalid<=1; m_wdata<=HWDATA; m_wstrb<={(DW/8){1'b1}}; m_wlast<=1; state<=ST_WD; end else m_awvalid<=1;
                ST_WD: if(m_bvalid) begin HRESP<=m_bresp[1]; HREADY_OUT<=1; state<=ST_IDLE; end else m_wvalid<=1;
                ST_AR: if(m_arready) state<=ST_RD; else m_arvalid<=1;
                ST_RD: if(m_rvalid) begin HRDATA<=m_rdata; HRESP<=m_rresp[1]; HREADY_OUT<=1; state<=ST_IDLE; end
            endcase
        end
    end
endmodule
