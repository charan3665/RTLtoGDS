// ahb_bridge.v - AXI4 to AHB5 Bridge
`timescale 1ns/1ps
module ahb_bridge #(parameter AW=32, DW=64)(
    input wire HCLK, input wire HRESETn,
    // AXI4-Lite slave
    input  wire s_awvalid, input wire [AW-1:0] s_awaddr, output wire s_awready,
    input  wire s_wvalid,  input wire [DW-1:0] s_wdata, output wire s_wready,
    output reg  s_bvalid,  output reg [1:0] s_bresp, input wire s_bready,
    input  wire s_arvalid, input wire [AW-1:0] s_araddr, output wire s_arready,
    output reg  s_rvalid,  output reg [DW-1:0] s_rdata, output reg [1:0] s_rresp, input wire s_rready,
    // AHB master
    output reg [AW-1:0] HADDR, output reg [2:0] HBURST, output reg [2:0] HSIZE,
    output reg [1:0] HTRANS, output reg [DW-1:0] HWDATA, output reg HWRITE,
    input wire [DW-1:0] HRDATA, input wire HREADY, input wire HRESP
);
    localparam IDLE=2'b00, NONSEQ=2'b10, SEQ=2'b11;
    localparam ST_IDLE=3'd0, ST_ADDR=3'd1, ST_DATA=3'd2, ST_RESP=3'd3;
    reg [2:0] state; reg is_wr_r;
    assign s_awready=(state==ST_IDLE); assign s_wready=(state==ST_ADDR)&&is_wr_r;
    assign s_arready=(state==ST_IDLE);
    always @(posedge HCLK or negedge HRESETn) begin
        if(!HRESETn) begin state<=ST_IDLE; HTRANS<=IDLE; s_bvalid<=0; s_rvalid<=0; end
        else begin
            case(state)
                ST_IDLE: begin
                    s_bvalid<=0; s_rvalid<=0; HTRANS<=IDLE;
                    if(s_awvalid) begin HADDR<=s_awaddr; HWRITE<=1; HSIZE<=3'b011; HTRANS<=NONSEQ; is_wr_r<=1; state<=ST_ADDR; end
                    else if(s_arvalid) begin HADDR<=s_araddr; HWRITE<=0; HSIZE<=3'b011; HTRANS<=NONSEQ; is_wr_r<=0; state<=ST_DATA; end
                end
                ST_ADDR: if(s_wvalid) begin HWDATA<=s_wdata; HTRANS<=NONSEQ; state<=ST_DATA; end
                ST_DATA: if(HREADY) begin
                    HTRANS<=IDLE;
                    if(is_wr_r) begin s_bvalid<=1; s_bresp<=HRESP?2'b10:2'b00; state<=ST_RESP; end
                    else begin s_rvalid<=1; s_rdata<=HRDATA; s_rresp<=HRESP?2'b10:2'b00; state<=ST_RESP; end
                end
                ST_RESP: begin
                    if(is_wr_r&&s_bready) begin s_bvalid<=0; state<=ST_IDLE; end
                    if(!is_wr_r&&s_rready) begin s_rvalid<=0; state<=ST_IDLE; end
                end
            endcase
        end
    end
endmodule
