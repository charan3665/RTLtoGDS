`timescale 1ns/1ps
module noc_switch_allocator #(parameter PORTS=5)(
    input wire clk, input wire rst_n,
    input  wire [PORTS-1:0] req [0:PORTS-1],  // req[in][out]
    output reg  [PORTS-1:0] grant [0:PORTS-1] // grant[in][out]
);
    integer i, j;
    reg [PORTS-1:0] out_used;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) for(i=0;i<PORTS;i=i+1) grant[i]<=0;
        else begin
            out_used=0;
            for(i=0;i<PORTS;i=i+1) grant[i]<=0;
            for(i=0;i<PORTS;i=i+1) begin
                for(j=0;j<PORTS;j=j+1) begin
                    if(req[i][j] && !out_used[j] && !|grant[i]) begin
                        grant[i][j]<=1; out_used[j]=1;
                    end
                end
            end
        end
    end
endmodule
