`timescale 1ns/1ps
module noc_flit_if #(parameter FLIT_WIDTH=128, N_VC=4)(
    input wire clk, input wire rst_n,
    // AXI4-S to flit conversion
    input  wire        s_valid, input wire [FLIT_WIDTH-1:0] s_data, input wire s_last, output wire s_ready,
    output reg         m_valid, output reg [FLIT_WIDTH-1:0] m_flit, output reg [1:0] m_flit_type,
    output reg [$clog2(N_VC)-1:0] m_vc, input wire m_ready
);
    localparam ST_IDLE=2'd0, ST_BODY=2'd1, ST_DONE=2'd2;
    reg [1:0] state;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=ST_IDLE; m_valid<=0; end
        else begin
            m_valid<=0;
            case(state)
                ST_IDLE: if(s_valid) begin m_valid<=1; m_flit<=s_data; m_flit_type<=2'b00; m_vc<=0; state<=s_last?ST_DONE:ST_BODY; end
                ST_BODY: if(s_valid&&m_ready) begin m_valid<=1; m_flit<=s_data; m_flit_type<=s_last?2'b10:2'b01; state<=s_last?ST_DONE:ST_BODY; end
                ST_DONE: if(m_ready) state<=ST_IDLE;
            endcase
        end
    end
    assign s_ready=(state==ST_IDLE||(state==ST_BODY&&m_ready));
endmodule
