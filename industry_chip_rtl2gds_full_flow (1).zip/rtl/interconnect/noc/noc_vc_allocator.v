`timescale 1ns/1ps
module noc_vc_allocator #(parameter N_VC=4, PORTS=5)(
    input wire clk, input wire rst_n,
    input  wire [PORTS-1:0] req_valid, input wire [PORTS*$clog2(N_VC)-1:0] req_vc,
    output reg  [PORTS-1:0] grant, output reg [PORTS*$clog2(N_VC)-1:0] alloc_vc,
    input  wire [N_VC-1:0]  vc_free  // which VCs are free
);
    integer i; reg [$clog2(N_VC)-1:0] rr;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin grant<=0; rr<=0; end
        else begin
            grant<=0;
            for(i=0;i<PORTS;i=i+1) begin
                if(req_valid[i] && |vc_free) begin
                    grant[i]<=1;
                    alloc_vc[i*$clog2(N_VC)+:$clog2(N_VC)]<=rr;
                    rr<=rr+1;
                end
            end
        end
    end
endmodule
