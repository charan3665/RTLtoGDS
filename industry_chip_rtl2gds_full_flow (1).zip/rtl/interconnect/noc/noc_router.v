// ============================================================
// noc_router.v - 2D Mesh NoC Router (5-port: N/S/E/W/Local)
// XY routing, virtual channels, wormhole switching
// ============================================================
`timescale 1ns/1ps

module noc_router #(
    parameter FLIT_WIDTH = 128,
    parameter N_VC       = 4,    // virtual channels per port
    parameter PORTS      = 5,    // N, S, E, W, Local
    parameter BUFFER_DEPTH = 8,
    parameter X_BITS     = 2,    // bits for X coordinate
    parameter Y_BITS     = 2,    // bits for Y coordinate
    parameter X_COORD    = 0,    // this router's X position
    parameter Y_COORD    = 0     // this router's Y position
)(
    input  wire                     clk,
    input  wire                     rst_n,

    // Input flits from 5 ports (N, S, E, W, Local)
    input  wire [PORTS-1:0]         in_valid,
    input  wire [PORTS*FLIT_WIDTH-1:0] in_flit,
    input  wire [PORTS*$clog2(N_VC)-1:0] in_vc,
    output wire [PORTS-1:0]         in_credit,  // flow control

    // Output flits to 5 ports
    output reg  [PORTS-1:0]         out_valid,
    output reg  [PORTS*FLIT_WIDTH-1:0] out_flit,
    output reg  [PORTS*$clog2(N_VC)-1:0] out_vc,
    input  wire [PORTS-1:0]         out_credit
);

    // Flit type encoding (in header flit bits [1:0])
    localparam FLIT_HEAD = 2'b00;
    localparam FLIT_BODY = 2'b01;
    localparam FLIT_TAIL = 2'b10;

    // Header flit fields: [1:0]=type, [5:2]=dst_x, [9:6]=dst_y, [FLIT_WIDTH-1:10]=payload
    localparam TYPE_LSB = 0;
    localparam DST_X_LSB = 2;
    localparam DST_Y_LSB = 6;

    // Input buffers (one per port per VC)
    reg [FLIT_WIDTH-1:0] ibuf [0:PORTS-1][0:N_VC-1][0:BUFFER_DEPTH-1];
    reg [$clog2(BUFFER_DEPTH):0] ibuf_cnt [0:PORTS-1][0:N_VC-1];
    reg [$clog2(BUFFER_DEPTH)-1:0] ibuf_head [0:PORTS-1][0:N_VC-1];
    reg [$clog2(BUFFER_DEPTH)-1:0] ibuf_tail [0:PORTS-1][0:N_VC-1];

    // Routing table (XY routing)
    // Port encoding: 0=N, 1=S, 2=E, 3=W, 4=Local
    function [2:0] xy_route;
        input [X_BITS-1:0] dst_x;
        input [Y_BITS-1:0] dst_y;
        begin
            if (dst_x > X_COORD)       xy_route = 3'd2; // East
            else if (dst_x < X_COORD)  xy_route = 3'd3; // West
            else if (dst_y > Y_COORD)  xy_route = 3'd1; // South
            else if (dst_y < Y_COORD)  xy_route = 3'd0; // North
            else                       xy_route = 3'd4; // Local
        end
    endfunction

    // Switch allocator state
    reg [PORTS-1:0][PORTS-1:0] switch_state; // [in][out] allocation
    reg [PORTS-1:0]            port_active;

    // Credit counters for output ports
    reg [$clog2(BUFFER_DEPTH):0] ocredit [0:PORTS-1][0:N_VC-1];

    integer p, v, i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_valid <= {PORTS{1'b0}};
            for (p=0;p<PORTS;p=p+1) for(v=0;v<N_VC;v=v+1) begin
                ibuf_cnt[p][v]<=0; ibuf_head[p][v]<=0; ibuf_tail[p][v]<=0;
                ocredit[p][v]<=BUFFER_DEPTH;
            end
        end else begin
            out_valid <= {PORTS{1'b0}};

            // Receive flits
            for (p=0;p<PORTS;p=p+1) begin
                if (in_valid[p]) begin
                    automatic reg [$clog2(N_VC)-1:0] vc = in_vc[p*$clog2(N_VC) +: $clog2(N_VC)];
                    if (ibuf_cnt[p][vc] < BUFFER_DEPTH) begin
                        ibuf[p][vc][ibuf_tail[p][vc]] <= in_flit[p*FLIT_WIDTH +: FLIT_WIDTH];
                        ibuf_tail[p][vc] <= ibuf_tail[p][vc] + 1;
                        ibuf_cnt [p][vc] <= ibuf_cnt [p][vc] + 1;
                    end
                end
            end

            // Route and forward (simplified: process one flit per port per cycle)
            for (p=0;p<PORTS;p=p+1) begin
                for (v=0;v<N_VC;v=v+1) begin
                    if (ibuf_cnt[p][v] > 0) begin
                        automatic reg [FLIT_WIDTH-1:0] flit = ibuf[p][v][ibuf_head[p][v]];
                        automatic reg [X_BITS-1:0] dst_x = flit[DST_X_LSB +: X_BITS];
                        automatic reg [Y_BITS-1:0] dst_y = flit[DST_Y_LSB +: Y_BITS];
                        automatic reg [2:0] out_port = xy_route(dst_x, dst_y);
                        if (!out_valid[out_port]) begin
                            out_valid[out_port] <= 1'b1;
                            out_flit[out_port*FLIT_WIDTH +: FLIT_WIDTH] <= flit;
                            out_vc  [out_port*$clog2(N_VC) +: $clog2(N_VC)] <= v[$clog2(N_VC)-1:0];
                            ibuf_head[p][v] <= ibuf_head[p][v] + 1;
                            ibuf_cnt [p][v] <= ibuf_cnt [p][v] - 1;
                        end
                    end
                end
            end
        end
    end

    // Credit output: space available in input buffers
    genvar gp, gv;
    generate
        for (gp = 0; gp < PORTS; gp = gp + 1) begin : gen_credit
            assign in_credit[gp] = (ibuf_cnt[gp][0] < BUFFER_DEPTH);
        end
    endgenerate

endmodule
