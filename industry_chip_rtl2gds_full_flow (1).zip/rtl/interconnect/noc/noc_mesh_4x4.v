// ============================================================
// noc_mesh_4x4.v - 4x4 2D Mesh NoC (16 routers)
// ============================================================
`timescale 1ns/1ps
module noc_mesh_4x4 #(
    parameter FLIT_WIDTH = 128,
    parameter N_VC       = 4
)(
    input  wire         clk, input wire rst_n,
    // Local injection/ejection ports (16 nodes)
    input  wire [15:0]  local_in_valid,
    input  wire [16*FLIT_WIDTH-1:0] local_in_flit,
    output wire [15:0]  local_in_credit,
    output wire [15:0]  local_out_valid,
    output wire [16*FLIT_WIDTH-1:0] local_out_flit
);
    // Inter-router connection wires: [router][port]
    wire [4:0]           r_out_valid  [0:15];
    wire [5*FLIT_WIDTH-1:0] r_out_flit[0:15];
    wire [5*$clog2(N_VC)-1:0] r_out_vc [0:15];
    wire [4:0]           r_in_credit  [0:15];
    wire [4:0]           r_in_valid   [0:15];
    wire [5*FLIT_WIDTH-1:0] r_in_flit [0:15];
    wire [5*$clog2(N_VC)-1:0] r_in_vc [0:15];

    genvar gx, gy;
    generate
        for (gy = 0; gy < 4; gy = gy + 1) begin : gen_row
            for (gx = 0; gx < 4; gx = gx + 1) begin : gen_col
                localparam ID = gy*4 + gx;
                // Neighbor indices
                localparam N_ID = (gy>0) ? (gy-1)*4+gx : ID; // N neighbor
                localparam S_ID = (gy<3) ? (gy+1)*4+gx : ID; // S neighbor
                localparam E_ID = (gx<3) ? gy*4+(gx+1) : ID; // E neighbor
                localparam W_ID = (gx>0) ? gy*4+(gx-1) : ID; // W neighbor

                noc_router #(
                    .FLIT_WIDTH(FLIT_WIDTH), .N_VC(N_VC),
                    .X_COORD(gx), .Y_COORD(gy)
                ) u_router (
                    .clk(clk), .rst_n(rst_n),
                    // Input: N=0, S=1, E=2, W=3, Local=4
                    .in_valid ({(gy>0?r_out_valid[N_ID][1]:1'b0), (gy<3?r_out_valid[S_ID][0]:1'b0),
                                (gx<3?r_out_valid[E_ID][3]:1'b0), (gx>0?r_out_valid[W_ID][2]:1'b0),
                                local_in_valid[ID]}),
                    .in_flit  ({(gy>0?r_out_flit[N_ID][1*FLIT_WIDTH+:FLIT_WIDTH]:{FLIT_WIDTH{1'b0}}),
                                (gy<3?r_out_flit[S_ID][0*FLIT_WIDTH+:FLIT_WIDTH]:{FLIT_WIDTH{1'b0}}),
                                (gx<3?r_out_flit[E_ID][3*FLIT_WIDTH+:FLIT_WIDTH]:{FLIT_WIDTH{1'b0}}),
                                (gx>0?r_out_flit[W_ID][2*FLIT_WIDTH+:FLIT_WIDTH]:{FLIT_WIDTH{1'b0}}),
                                local_in_flit[ID*FLIT_WIDTH+:FLIT_WIDTH]}),
                    .in_vc    ({(4*$clog2(N_VC)){1'b0}, {$clog2(N_VC){1'b0}}}),
                    .in_credit(r_in_credit[ID]),
                    .out_valid(r_out_valid[ID]),
                    .out_flit (r_out_flit[ID]),
                    .out_vc   (r_out_vc[ID]),
                    .out_credit({4'b1111,1'b1})
                );
                assign local_out_valid[ID]                    = r_out_valid[ID][4];
                assign local_out_flit[ID*FLIT_WIDTH+:FLIT_WIDTH] = r_out_flit[ID][4*FLIT_WIDTH+:FLIT_WIDTH];
                assign local_in_credit[ID]                    = r_in_credit[ID][4];
            end
        end
    endgenerate
endmodule
