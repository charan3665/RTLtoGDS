`timescale 1ns/1ps
module noc_input_buffer #(parameter FLIT_WIDTH=128, N_VC=4, DEPTH=8)(
    input wire clk, input wire rst_n,
    input  wire in_valid, input wire [FLIT_WIDTH-1:0] in_flit, input wire [$clog2(N_VC)-1:0] in_vc,
    output wire in_ready,
    output reg  out_valid, output reg [FLIT_WIDTH-1:0] out_flit, output reg [$clog2(N_VC)-1:0] out_vc,
    input  wire out_ready
);
    reg [FLIT_WIDTH+$clog2(N_VC):0] buf[0:DEPTH-1];
    reg [$clog2(DEPTH):0] cnt; reg [$clog2(DEPTH)-1:0] head, tail;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin cnt<=0; head<=0; tail<=0; out_valid<=0; end
        else begin
            if(in_valid&&in_ready) begin buf[tail]<={in_vc,in_flit}; tail<=tail+1; cnt<=cnt+(out_valid&&out_ready?0:1); end
            if(out_valid&&out_ready) begin {out_vc,out_flit}<=buf[head]; head<=head+1; cnt<=cnt-1; out_valid<=(cnt>1); end
            else if(!out_valid&&cnt>0) begin {out_vc,out_flit}<=buf[head]; head<=head+1; cnt<=cnt-1; out_valid<=1; end
        end
    end
    assign in_ready=(cnt<DEPTH);
endmodule
