// axi4_arbiter.v - Priority/Round-Robin AXI4 Request Arbiter
`timescale 1ns/1ps
module axi4_arbiter #(parameter N=8)(
    input  wire         clk, input wire rst_n,
    input  wire [N-1:0] req,         // request vector
    input  wire [N-1:0] ack,         // transaction done
    output reg  [N-1:0] grant,       // one-hot grant
    output reg  [$clog2(N)-1:0] grant_id
);
    reg [$clog2(N)-1:0] rr_ptr;
    integer i, k;
    reg found;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin grant<=1; grant_id<=0; rr_ptr<=0; end
        else begin
            if (|(grant & ack)) begin  // current grant completed
                found=0;
                for (k=1;k<=N;k=k+1) begin
                    automatic integer nxt=(rr_ptr+k)%N;
                    if(req[nxt]&&!found) begin grant<=(1<<nxt); grant_id<=nxt[$clog2(N)-1:0]; rr_ptr<=nxt[$clog2(N)-1:0]; found=1; end
                end
                if(!found) begin grant<={N{1'b0}}; end
            end else if(!|grant && |req) begin
                found=0;
                for(k=0;k<N;k=k+1) begin
                    automatic integer nxt=(rr_ptr+k)%N;
                    if(req[nxt]&&!found) begin grant<=(1<<nxt); grant_id<=nxt[$clog2(N)-1:0]; found=1; end
                end
            end
        end
    end
endmodule
