// axi4_master_if.v - AXI4 Master Interface (pipeline register slice)
`timescale 1ns/1ps
module axi4_master_if #(parameter AW=64, DW=128, IW=12)(
    input wire aclk, input wire aresetn,
    // From master
    input  wire        s_awvalid, input  wire [IW-1:0] s_awid, input  wire [AW-1:0] s_awaddr,
    input  wire [7:0]  s_awlen,   input  wire [2:0] s_awsize, input wire [1:0] s_awburst,
    output wire        s_awready,
    input  wire        s_wvalid,  input  wire [DW-1:0] s_wdata, input wire [DW/8-1:0] s_wstrb, input wire s_wlast,
    output wire        s_wready,
    output wire        s_bvalid,  output wire [IW-1:0] s_bid, output wire [1:0] s_bresp, input wire s_bready,
    input  wire        s_arvalid, input  wire [IW-1:0] s_arid, input  wire [AW-1:0] s_araddr,
    input  wire [7:0]  s_arlen,   input  wire [2:0] s_arsize, input wire [1:0] s_arburst,
    output wire        s_arready,
    output wire        s_rvalid,  output wire [IW-1:0] s_rid, output wire [DW-1:0] s_rdata,
    output wire [1:0]  s_rresp,   output wire s_rlast, input wire s_rready,
    // To crossbar
    output reg         m_awvalid, output reg  [IW-1:0] m_awid, output reg  [AW-1:0] m_awaddr,
    output reg [7:0]   m_awlen,   output reg  [2:0] m_awsize, output reg [1:0] m_awburst,
    input  wire        m_awready,
    output reg         m_wvalid,  output reg  [DW-1:0] m_wdata, output reg [DW/8-1:0] m_wstrb, output reg m_wlast,
    input  wire        m_wready,
    input  wire        m_bvalid,  input  wire [IW-1:0] m_bid, input  wire [1:0] m_bresp, output wire m_bready,
    output reg         m_arvalid, output reg  [IW-1:0] m_arid, output reg  [AW-1:0] m_araddr,
    output reg [7:0]   m_arlen,   output reg  [2:0] m_arsize, output reg [1:0] m_arburst,
    input  wire        m_arready,
    input  wire        m_rvalid,  input  wire [IW-1:0] m_rid, input  wire [DW-1:0] m_rdata,
    input  wire [1:0]  m_rresp,   input  wire m_rlast, output wire m_rready
);
    // Pipeline register slice (skid buffer)
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin m_awvalid<=0; m_wvalid<=0; m_arvalid<=0; end
        else begin
            if (!m_awvalid || m_awready) begin m_awvalid<=s_awvalid; m_awid<=s_awid; m_awaddr<=s_awaddr; m_awlen<=s_awlen; m_awsize<=s_awsize; m_awburst<=s_awburst; end
            if (!m_wvalid  || m_wready)  begin m_wvalid<=s_wvalid;   m_wdata<=s_wdata; m_wstrb<=s_wstrb; m_wlast<=s_wlast; end
            if (!m_arvalid || m_arready) begin m_arvalid<=s_arvalid; m_arid<=s_arid; m_araddr<=s_araddr; m_arlen<=s_arlen; m_arsize<=s_arsize; m_arburst<=s_arburst; end
        end
    end
    assign s_awready = m_awready; assign s_wready  = m_wready;  assign s_arready = m_arready;
    assign s_bvalid  = m_bvalid;  assign s_bid     = m_bid;     assign s_bresp   = m_bresp; assign m_bready = s_bready;
    assign s_rvalid  = m_rvalid;  assign s_rid     = m_rid;     assign s_rdata   = m_rdata; assign s_rresp  = m_rresp; assign s_rlast = m_rlast; assign m_rready = s_rready;
endmodule
