// axi4_id_remap.v - AXI4 Transaction ID Remapping
// Stores original ID, issues sequential IDs to slave, remaps responses back
`timescale 1ns/1ps
module axi4_id_remap #(parameter IW_IN=8, IW_OUT=12, DEPTH=32)(
    input wire clk, input wire rst_n,
    input  wire [IW_IN-1:0]  orig_id_in,   input wire alloc_en,
    output wire [IW_OUT-1:0] remap_id_out, output wire alloc_ready,
    input  wire [IW_OUT-1:0] remap_id_resp, input wire resp_valid,
    output wire [IW_IN-1:0]  orig_id_out,  output wire orig_valid
);
    reg [IW_IN-1:0]  id_table[0:DEPTH-1];
    reg [DEPTH-1:0]  valid;
    reg [$clog2(DEPTH):0] cnt;
    reg [$clog2(DEPTH)-1:0] alloc_ptr;
    integer i; reg af;
    always @(*) begin af=0; alloc_ptr=0; for(i=0;i<DEPTH;i=i+1) if(!valid[i]&&!af) begin alloc_ptr=i[$clog2(DEPTH)-1:0]; af=1; end end
    assign alloc_ready=af;
    assign remap_id_out={{(IW_OUT-$clog2(DEPTH)){1'b0}},alloc_ptr};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin valid<=0; cnt<=0; end
        else begin
            if(alloc_en&&af) begin id_table[alloc_ptr]<=orig_id_in; valid[alloc_ptr]<=1; cnt<=cnt+1; end
            if(resp_valid) begin valid[remap_id_resp[$clog2(DEPTH)-1:0]]<=0; cnt<=cnt-1; end
        end
    end
    assign orig_id_out = id_table[remap_id_resp[$clog2(DEPTH)-1:0]];
    assign orig_valid  = resp_valid && valid[remap_id_resp[$clog2(DEPTH)-1:0]];
endmodule
