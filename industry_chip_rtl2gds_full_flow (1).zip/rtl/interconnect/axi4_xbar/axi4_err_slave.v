// axi4_err_slave.v - AXI4 Error Slave (returns DECERR for all transactions)
`timescale 1ns/1ps
module axi4_err_slave #(parameter AW=64, DW=128, IW=12)(
    input wire aclk, input wire aresetn,
    input  wire s_awvalid, input wire [IW-1:0] s_awid, input wire [AW-1:0] s_awaddr, input wire [7:0] s_awlen, output wire s_awready,
    input  wire s_wvalid,  input wire [DW-1:0] s_wdata, input wire [DW/8-1:0] s_wstrb, input wire s_wlast, output wire s_wready,
    output reg  s_bvalid,  output reg  [IW-1:0] s_bid, output reg [1:0] s_bresp, input wire s_bready,
    input  wire s_arvalid, input wire [IW-1:0] s_arid, input wire [AW-1:0] s_araddr, input wire [7:0] s_arlen, output wire s_arready,
    output reg  s_rvalid,  output reg  [IW-1:0] s_rid, output reg [DW-1:0] s_rdata, output reg [1:0] s_rresp, output reg s_rlast, input wire s_rready
);
    assign s_awready=1'b1; assign s_wready=1'b1; assign s_arready=1'b1;
    always @(posedge aclk or negedge aresetn) begin
        if(!aresetn) begin s_bvalid<=0; s_rvalid<=0; end
        else begin
            if(s_awvalid) begin s_bvalid<=1; s_bid<=s_awid; s_bresp<=2'b11; end // DECERR
            else if(s_bready) s_bvalid<=0;
            if(s_arvalid) begin s_rvalid<=1; s_rid<=s_arid; s_rdata<={DW{1'b0}}; s_rresp<=2'b11; s_rlast<=1; end
            else if(s_rready) s_rvalid<=0;
        end
    end
endmodule
