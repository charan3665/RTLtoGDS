// axi4_decoder.v - AXI4 Address Decoder (maps address to slave select)
`timescale 1ns/1ps
module axi4_decoder #(parameter AW=64, NS=8)(
    input  wire [AW-1:0]        addr,
    output reg  [NS-1:0]        slave_sel,
    output reg                  decode_err
);
    // Memory map:
    // 0x0000_0000_0000_0000 - 0x0FFF_FFFF_FFFF_FFFF : Slave 0 (CPU/L3)
    // 0x1000_0000_0000_0000 - 0x1FFF_FFFF_FFFF_FFFF : Slave 1 (GPU)
    // 0x2000_0000_0000_0000 - 0x2FFF_FFFF_FFFF_FFFF : Slave 2 (DRAM)
    // 0x3000_0000_0000_0000 - 0x3FFF_FFFF_FFFF_FFFF : Slave 3 (PCIe)
    // 0x4000_0000_0000_0000 - 0x4FFF_FFFF_FFFF_FFFF : Slave 4 (Crypto/DMA)
    // 0x5000_0000_0000_0000 - 0x5FFF_FFFF_FFFF_FFFF : Slave 5 (USB/ETH)
    // 0x6000_0000_0000_0000 - 0x6FFF_FFFF_FFFF_FFFF : Slave 6 (Peripherals)
    // Others                                         : Slave 7 (Error)
    always @(*) begin
        slave_sel  = {NS{1'b0}};
        decode_err = 1'b0;
        case (addr[63:60])
            4'h0: slave_sel[0] = 1'b1;
            4'h1: slave_sel[1] = 1'b1;
            4'h2: slave_sel[2] = 1'b1;
            4'h3: slave_sel[3] = 1'b1;
            4'h4: slave_sel[4] = 1'b1;
            4'h5: slave_sel[5] = 1'b1;
            4'h6: slave_sel[6] = 1'b1;
            default: begin slave_sel[7] = 1'b1; decode_err = 1'b1; end
        endcase
    end
endmodule
