// axi4_data_fifo.v - AXI4 Data Channel FIFO (for pipelining)
`timescale 1ns/1ps
module axi4_data_fifo #(parameter DW=128, STRB=16, DEPTH=8)(
    input  wire             clk, input wire rst_n,
    input  wire             wr_valid, input wire [DW-1:0] wr_data, input wire [STRB-1:0] wr_strb, input wire wr_last,
    output wire             wr_ready,
    output wire             rd_valid, output wire [DW-1:0] rd_data, output wire [STRB-1:0] rd_strb, output wire rd_last,
    input  wire             rd_ready
);
    reg [DW+STRB:0] mem[0:DEPTH-1]; // data+strb+last
    reg [$clog2(DEPTH):0] head, tail, count;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin head<=0; tail<=0; count<=0; end
        else begin
            if(wr_valid&&wr_ready) begin mem[tail%DEPTH]<={wr_last,wr_strb,wr_data}; tail<=tail+1; count<=count+1; end
            if(rd_valid&&rd_ready) begin head<=head+1; count<=count-1; end
        end
    end
    assign wr_ready=(count<DEPTH);
    assign rd_valid=(count>0);
    assign {rd_last,rd_strb,rd_data}=mem[head%DEPTH];
endmodule
